Upright Piano KW 音源を使ったオリジナルピアノ試聴版
================================================

中身：
 .github/workflows/render-kw-piano.yml
 scripts/make_midi.py

使い方（GitHub）：
1. 新規の空のGitHubリポジトリを作る（既存のYouTube動画生成リポジトリとは分けることを推奨）。
2. ZIPを展開して、.github/workflows/render-kw-piano.yml と scripts/make_midi.py をアップロード。
   （GitHub上にZIPファイルだけを置いても動作しません）
3. リポジトリの Actions → Render FreePats Upright Piano KW sample → Run workflow を選択。
4. 成功後、実行画面の Artifacts 欄にある Upright-KW-Piano-Preview をダウンロード。
5. 中の Upright_KW_Original_Piano.mp3 が実際のKAWAIアップライトピアノのサンプル音を使った試聴版。

ライセンス：FreePats Upright Piano KW は CC0 1.0。商用利用可能。
公式：https://freepats.zenvoid.org/Piano/acoustic-grand-piano.html#UprightKW

重要：これは「GitHub Actionsで実行して完成させる制作キット」です。
この環境では公式音源ファイルをダウンロードできておらず、KWによるMP3生成の実動作検証はまだ行えていません。
元曲・MIDI生成ロジックはオリジナル。試聴版の長さは約4分半。
